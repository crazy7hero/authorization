load(qt_parts)
